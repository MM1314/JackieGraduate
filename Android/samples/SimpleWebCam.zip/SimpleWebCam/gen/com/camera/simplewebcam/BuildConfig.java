/** Automatically generated file. DO NOT MODIFY */
package com.camera.simplewebcam;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}