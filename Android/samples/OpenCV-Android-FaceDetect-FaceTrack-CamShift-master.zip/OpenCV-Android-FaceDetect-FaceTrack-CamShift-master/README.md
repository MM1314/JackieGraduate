OpenCV-Android-FaceDetect-FaceTrack-CamShift
============================================

Android OpenCV Sample Code to Detect and Track Face using calcBackProject and Camshift Algorithm. Press the Menu , "Start" to start Tracking initializing and tracking.
This uses handset front camera to track human face.Check CamShifting.java for code logic behind this.

This has been tested in Sony Neo V handset , Android SDK ver 4.x

The code contains comments, wherever necessary.

Important: Make sure, you are importing and adding OpenCV library , while building this application.

Detailed Tutorial at http://imranakthar.com/android-opencv-tutorial-3-face-tracking-using-camshift-histogram/

imran [AT] imranakthar [DOT] com

imranakthar.com
