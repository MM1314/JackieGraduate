OpenCV-Android-FaceDetect-ORB-BRIEF-FLANN
=========================================

Android OpenCV Sample Code to showcase ORB,FLANN. The example also contains Face Tracker and Detector using these techniques.

Press the Menu , "ORB","BRIEF" and "Track" .ORB and BRIEF menu demostrates the algorithm, whereas Track is integrated with Face Tracking Algorithm.Explore FdView.java for more details.

As these API are computationally expensive, you will experince slower performance , in your live video.

This has been tested in Sony Neo V handset , Android SDK ver 4.x

The code contains comments, wherever necessary.

Important: Make sure, you are importing and adding OpenCV library , while building this application.

imran [AT] imranakthar [DOT] com

imranakthar.com
