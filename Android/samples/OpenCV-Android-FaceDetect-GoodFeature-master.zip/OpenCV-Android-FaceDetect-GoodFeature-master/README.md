OpenCV-Android-FaceDetect-GoodFeature
=====================================

Android OpenCV Sample Code to Detect and Track Face using GoodFeature to Track API. Press the Menu , "Start" to start Tracking 

Android OpenCV Sample Code to Detect and Track Face using GoodFeature to Track API.

The code uses calcOpticalFlowPyrLK and goodFeaturesToTrack to Track Face Features. It resets the tracker once percentage of error crosses an particular limit. This uses handset front camera to track human face.Check HeadPose.java for logic behind this.

Press the Menu , "Start" to start Tracking .You will see Status of the App, either "NONE" or "TRACKING:.

This has been tested in Sony Neo V handset , Android SDK ver 4.x

The code contains comments, wherever necessary.

Important: Make sure, you are importing and adding OpenCV library , while building this application.

Detailed tutorial http://imranakthar.com/android-opencv-tutorial-2-face-tracking-using-optical-flow-goodfeaturetotrack-api/


imran [AT] imranakthar [DOT] com

imranakthar.com
