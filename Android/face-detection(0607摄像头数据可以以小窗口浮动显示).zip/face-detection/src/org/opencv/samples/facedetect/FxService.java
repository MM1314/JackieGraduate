package org.opencv.samples.facedetect;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.JavaCameraView;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.objdetect.CascadeClassifier;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FxService extends Service implements CvCameraViewListener2{
    private static final String    TAG                 = "OCVSample::Service";
    private static final Scalar    FACE_RECT_COLOR     = new Scalar(0, 255, 0, 255);
    public static final int        JAVA_DETECTOR       = 0;
    public static final int        NATIVE_DETECTOR     = 1;
    
    private Mat                    mRgba;
    private Mat                    mGray;
    private File                   mCascadeFile;
    private CascadeClassifier      mJavaDetector;
    private DetectionBasedTracker  mNativeDetector;

    private int                    mDetectorType       = JAVA_DETECTOR;
    private String[]               mDetectorName;

    private float                  mRelativeFaceSize   = 0.2f;
    private int                    mAbsoluteFaceSize   = 0;
	private CameraBridgeViewBase   mOpenCvCameraView;
	
	//回调
	private BaseLoaderCallback  mLoaderCallback = new BaseLoaderCallback(this) {
	        @Override
	        public void onManagerConnected(int status) {
	            switch (status) {
	                case LoaderCallbackInterface.SUCCESS:
	                {
	                    Log.i(TAG, "OpenCV loaded successfully");

	                    // Load native library after(!) OpenCV initialization
	                    System.loadLibrary("detection_based_tracker");

	                    try {
	                        // load cascade file from application resources
	                        InputStream is = getResources().openRawResource(R.raw.lbpcascade_frontalface);
	                        File cascadeDir = getDir("cascade", Context.MODE_PRIVATE);
	                        mCascadeFile = new File(cascadeDir, "lbpcascade_frontalface.xml");
	                        FileOutputStream os = new FileOutputStream(mCascadeFile);

	                        byte[] buffer = new byte[4096];
	                        int bytesRead;
	                        while ((bytesRead = is.read(buffer)) != -1) {
	                            os.write(buffer, 0, bytesRead);
	                        }
	                        is.close();
	                        os.close();

	                        mJavaDetector = new CascadeClassifier(mCascadeFile.getAbsolutePath());
	                        
	                        if (mJavaDetector.empty()) {
	                            Log.e(TAG, "Failed to load cascade classifier");
	                            mJavaDetector = null;
	                        } else
	                            Log.i(TAG, "Loaded cascade classifier from " + mCascadeFile.getAbsolutePath());

	                        mNativeDetector = new DetectionBasedTracker(mCascadeFile.getAbsolutePath(), 0);

	                        cascadeDir.delete();

	                    } catch (IOException e) {
	                        e.printStackTrace();
	                        Log.e(TAG, "Failed to load cascade. Exception thrown: " + e);
	                    }

	                    mOpenCvCameraView.enableView();
	                } break;
	                default:
	                {
	                    super.onManagerConnected(status);
	                } break;
	            }
	        }
	    };
	    
	LinearLayout mFloatLayout;
	WindowManager.LayoutParams wmParams;
	WindowManager mWindowManager;
	//Button mOpenCvCameraView;
	JavaCameraView mFloatView;
	//private static final String TAG = "FXService";
	
    public FxService() {
        mDetectorName = new String[2];
        mDetectorName[JAVA_DETECTOR] = "Java";
        mDetectorName[NATIVE_DETECTOR] = "Native (tracking)";

        Log.i(TAG, "Instantiated new " + this.getClass());
    }
	
	@Override
	public void onCreate() {
		super.onCreate();
		Log.i(TAG, "onCreate");
		createFloatView();
	
	        //使其一直位于屏幕前端
		//((Intent) mWindowManager).addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

	        //setContentView(R.layout.face_detect_surface_view);

	      //  mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.fd_activity_surface_view);
	      //  mOpenCvCameraView.setCvCameraViewListener(this);
	}


	private void createFloatView() {
		// TODO Auto-generated method stub
		wmParams = new WindowManager.LayoutParams();
		mWindowManager = (WindowManager)getApplication().getSystemService(getApplication().WINDOW_SERVICE);
		Log.i(TAG, "mWindowManager---> " + mWindowManager);
		
		wmParams.type = LayoutParams.TYPE_PHONE;
		//设置图片格式，效果为背景透明  
		wmParams.format = PixelFormat.RGBA_8888;
		//设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
		wmParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		//调整悬浮窗显示的停靠位置为左侧置顶  
		wmParams.gravity = Gravity.RIGHT | Gravity.TOP;
		wmParams.x = 0;
		wmParams.y = 0;
		
		//设置悬浮窗口长宽数据    
		//wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
		//wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
		
		wmParams.width = 200;
		wmParams.height = 150;
		
		LayoutInflater inflater = LayoutInflater.from(getApplication());
		mFloatLayout = (LinearLayout) inflater.inflate(R.layout.face_detect_surface_view, null);
		
		mWindowManager.addView(mFloatLayout, wmParams);
		//浮动窗口按钮  
		//mFloatView = (Button)mFloatLayout.findViewById(R.id.float_id);
		//mFloatView = (CameraBridgeViewBase)mFloatLayout.findViewById(R.id.fd_activity_surface_view);
		
		 mOpenCvCameraView = (CameraBridgeViewBase)mFloatLayout.findViewById(R.id.fd_activity_surface_view);
		 
	        mOpenCvCameraView.setCvCameraViewListener(this);
		mFloatLayout.measure(View.MeasureSpec.makeMeasureSpec(0,
				View.MeasureSpec.UNSPECIFIED),View.MeasureSpec
				.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
		
		 Log.i(TAG, "Width/2--->" + mOpenCvCameraView.getMeasuredWidth()/2);  
	     Log.i(TAG, "Height/2--->" + mOpenCvCameraView.getMeasuredHeight()/2);
		
	   //设置监听浮动窗口的触摸移动 
	     mOpenCvCameraView.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				wmParams.x = (int)event.getRawX() - mOpenCvCameraView.getMeasuredWidth()/2;
				Log.i(TAG, "RawX" + event.getRawX());  
	            Log.i(TAG, "X" + event.getX());  
	             
	         	wmParams.y = (int)event.getRawY() - mOpenCvCameraView.getMeasuredWidth()/2 - 25;
				Log.i(TAG, "RawY" + event.getRawY());  
	            Log.i(TAG, "Y" + event.getY());  
				
	            mWindowManager.updateViewLayout(mFloatLayout, wmParams);
	           //此处必须返回false，否则OnClickListener获取不到监听
				return false;
			}
	    	 
	     });
	     
	     mOpenCvCameraView.setOnClickListener(new OnClickListener(){
	    	 @Override
	    	 public void onClick(View v){
	    		 Toast.makeText(FxService.this, "onClick", Toast.LENGTH_SHORT).show();
	    	 }
	     });
	}
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy(){
		super.onDestroy();
		if(mFloatLayout != null ){
			mOpenCvCameraView.disableView();
			mWindowManager.removeView(mFloatLayout);
		}
	}


	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		//加载OpenCVLoader
		OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_3, this, mLoaderCallback);
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public void onCameraViewStarted(int width, int height) {
		  mGray = new Mat();
	      mRgba = new Mat();
		}

	@Override
	public void onCameraViewStopped() {
		  mGray.release();
	      mRgba.release();
	}
	/*
	 * 在摄像头读入数据送时及进行处理
	 * */
	@Override
	public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
		  mRgba = inputFrame.rgba();
	        mGray = inputFrame.gray();

	        if (mAbsoluteFaceSize == 0) {
	            int height = mGray.rows();
	            if (Math.round(height * mRelativeFaceSize) > 0) {
	                mAbsoluteFaceSize = Math.round(height * mRelativeFaceSize);
	            }
	            mNativeDetector.setMinFaceSize(mAbsoluteFaceSize);
	        }

	        MatOfRect faces = new MatOfRect();

	        if (mDetectorType == JAVA_DETECTOR) {
	            if (mJavaDetector != null)
	                mJavaDetector.detectMultiScale(mGray, faces, 1.1, 2, 2, // TODO: objdetect.CV_HAAR_SCALE_IMAGE
	                        new Size(mAbsoluteFaceSize, mAbsoluteFaceSize), new Size());
	        }
	        else if (mDetectorType == NATIVE_DETECTOR) {
	            if (mNativeDetector != null)
	                mNativeDetector.detect(mGray, faces);
	        }
	        else {
	            Log.e(TAG, "Detection method is not selected!");
	        }

	        Rect[] facesArray = faces.toArray();
	        for (int i = 0; i < facesArray.length; i++)
	            Core.rectangle(mRgba, facesArray[i].tl(), facesArray[i].br(), FACE_RECT_COLOR, 3);
	        return mRgba;
	}
}
