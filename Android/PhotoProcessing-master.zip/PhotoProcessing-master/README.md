PhotoProcessing
===============

A demo of how you can process photos leveraging the ndk.

## Blur
The Stack Blur Algorithm by Mario Klingemann <mario@quasimondo.com> is used to perform blur operations.

## License
Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0.html)
